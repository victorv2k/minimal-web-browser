#!/bin/bash
omxplayer "$@"
xrefresh -display :0
